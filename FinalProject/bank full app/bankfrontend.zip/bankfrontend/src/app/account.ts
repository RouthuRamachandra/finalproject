export class Account {
    
    accountId: number;
    name: string;
    balance: number;
    dob: Date;
    accountCreationDate:Date;
    accountType: string;
    address: string;
    city: string;
    phone: string;
    email: string;
   
}
