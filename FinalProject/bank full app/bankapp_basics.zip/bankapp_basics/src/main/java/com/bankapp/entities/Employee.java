//package com.bankapp.entities;
//
//import java.time.LocalDate;
//
//import lombok.Data;
//@Data
//public class Employee {
//	
//	private int customerId;
//	private String name;
//	private String address;
//	private String city;
//	private String phone;
//	private String email;
//	private String password;
//	private LocalDate dob;
//	private EmployeeType profile;//mng /emp
//	
//
//}
